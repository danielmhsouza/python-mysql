O exercício consiste em utilizar python para gerenciar uma tabela de alunos.

O código permite inserir alunos e selecioná-los.
Para inserir basta usar a função IserirAluno(nome, idade).
Para selecioná-lo use a função SelecionarAlunoPorID(id).